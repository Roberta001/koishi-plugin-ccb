import { Computed, Context, Schema, Service } from 'koishi';
declare module 'koishi' {
    interface Context {
        monetary: Monetary;
    }
    namespace Command {
        interface Config {
            cost?: Computed<number>;
        }
    }
    interface Tables {
        monetary: Tables.Monetary;
    }
    namespace Tables {
        interface Monetary {
            uid: number;
            currency: string;
            value: number;
        }
    }
}
declare class Monetary extends Service {
    static inject: string[];
    constructor(ctx: Context, config: Monetary.Config);
    cost(uid: number, cost: number, currency?: string): Promise<void>;
    gain(uid: number, gain: number, currency?: string): Promise<void>;
}
declare namespace Monetary {
    interface Config {
    }
    const Config: Schema<Config>;
}
export default Monetary;
