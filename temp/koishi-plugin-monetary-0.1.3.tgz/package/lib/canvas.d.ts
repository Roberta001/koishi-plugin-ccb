/// <reference types="node" />
import CanvasService, { Canvas, CanvasRenderingContext2D, Image } from '@koishijs/canvas';
import { Page } from 'puppeteer-core';
declare const kElement: unique symbol;
declare class BaseElement {
    protected page: Page;
    protected id: string;
    [kElement]: boolean;
    constructor(page: Page, id: string);
    get selector(): string;
    dispose(): Promise<void>;
}
declare class CanvasElement extends BaseElement implements Canvas {
    width: number;
    height: number;
    private stmts;
    private ctx;
    constructor(page: Page, id: string, width: number, height: number);
    getContext(type: '2d'): CanvasRenderingContext2D<Canvas, Image>;
    toDataURL(type: 'image/png'): Promise<string>;
    toBuffer(type: 'image/png'): Promise<Buffer>;
}
export default class extends CanvasService {
    static using: string[];
    private page;
    private counter;
    start(): Promise<void>;
    stop(): Promise<void>;
    createCanvas(width: number, height: number): Promise<CanvasElement>;
    loadImage(source: string | URL | Buffer | ArrayBufferLike): Promise<Image>;
}
export {};
